
def test_genaric():
    a = 3
    b = 3
    assert a == b