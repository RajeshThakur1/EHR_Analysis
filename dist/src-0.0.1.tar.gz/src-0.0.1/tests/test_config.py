
def test_genaric():
    a =2
    b = 3
    assert a == b